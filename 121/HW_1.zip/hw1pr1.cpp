//Laura Austin
//CSCE 121-506
//Due: February 1, 2016
//hw1pr1.cpp
#include "std_lib_facilities_4.h"
 
int main()
{
	cout << "           3\n\n";
	cout << "       2 C L A R K E\n\n";
	cout << "           A\n\n";
	cout << "   1 S H A M I R\n\n";
	cout << "           P     B 4\n\n";
	cout << "15 D I J K S T R A\n\n";
	cout << "           O     C\n\n";
	cout << "       5 K N U T H\n\n";
	cout << "                 M     13\n\n";
	cout << " 6     7         A     R\n\n";
	cout << " W I L K I N S O N     I\n\n";
	cout << "       A        12 S U T H E R L A N D\n\n";
	cout << "       R         9     C\n\n";
	cout << "     8 P E R L I S  14 H O A R E\n\n";
	cout << "                 C     I\n\n";
	cout << "            10 C O C K E\n\n";
	cout << "                 T\n\n";
	cout << "              11 T H A C K E R\n\n\n";
	cout << "     DOWN                ACROSS\n\n";
	cout << "3 HRBB 226             1 HRBB 232\n";
	cout << "4 HRBB 217             2 HRBB 501A\n";
	cout << "7 HRBB 419A            5 HRBB 225\n";
	cout << "9 HRBB 224             6 HRBB 214\n";
	cout << "13 HRBB 213            8 HRBB 209\n";
	cout << "                       10 HRBB 221\n";
	cout << "                       11 HRBB 205\n";
	cout << "                       12 HRBB 514\n";
	cout << "                       14 HRBB 525\n";
	cout << "                       15 HRBB 526\n";
			// the winners first names!
			// 3 Butler 			1 Adi
			// 4 Charles			2 Edmund
			// 7 Richard			5 Donald
			// 9 Dana				6 James
			// 13 Dennis			8 Alan
			// 						10 John
			//						11 Charles
			//						12 Ivan
			//						14 C. Antony
			//						15 Edsger
return 0;
}
