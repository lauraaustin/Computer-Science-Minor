// implementation of member functions
#include <iostream>
#include "My_vec.h"
const int def_cap = 10; 				// want to keep this constant, could make a constructor 
										// so that the user can change this max value 
My_vec::My_vec() {
	size = 0; 							// empty
	capacity=def_cap;					// it points to a character value
	ptr = new char[capacity];			// memory allocated for char, the size of capacity	
	}
// destructor 
My_vec::~My_vec() {						// boolean "not", so delete== destructor
	delete[] ptr; 						// deletes value leaves space
}
// reference to the My_vec class object
// copy constructor (The TA went over this in lab)
My_vec::My_vec(const My_vec& vec):size(vec.size),capacity(vec.capacity),ptr(new char [vec.capacity]){
	for (int i = 0; i < size ; i++)
		ptr[i] = vec.ptr[i]; 
}

//http://www.cplusplus.com/articles/y8hv0pDG/
My_vec& My_vec::operator=(const My_vec& vec) { 	
	if(this != &vec){								// copy assignment operator
		delete ptr;						 					// delete old 
		size = vec.size;										// size is a member of object vec , 
		capacity = vec.capacity;								// passing vec.size into size
		ptr = new char[vec.capacity];							// size is a member of object vec
		for (int i=0; i < vec.size; i++)
			ptr[i] = vec.ptr[i];
	}
	return *this;
}

int My_vec::get_size() const {
	return size; 						// get_size is a member of class my_vec
}

int My_vec:: get_capacity() const {
	return capacity; 
}
  
char& My_vec::operator[](int i) const{	// essentially [] is just the index operation
	if (i<0 || i > ( size - 1 ))
		cerr << "RANK OUT OF RANGE" << endl;
	else
		return ptr[i];					// ptr[i] returned if [] is given
}

char& My_vec::operator [] (int i) {
		return ptr[i];
}

bool My_vec:: is_empty() const {
	return size == 0; 
}

char& My_vec:: elem_at_rank(int r) const{	// literally calling an element 
											// in the index return pointer[index]
	if (r < 0 || r > (size-1)) 				// can get elements from [0,size-1]
		cerr << "RANK OUT OF RANGE" << endl;
	else
		return ptr[r];
}

// referenced page 234 textbook code fragment 6.5
void My_vec:: insert_at_rank(int r, const char& elem){
	if (r<0 || r >= capacity)
		cerr << "RANK OUT OF RANGE" << endl;
	else if (r < (capacity-1) && r > (size+1))
		cerr << "RANK OUT OF RANGE" <<endl;	
	
	else if (size >= capacity){
		char * vec2 = new char[capacity*2];	// More memeory allocated
		for (int i = 0; i < size; i++)		// copying contents
			vec2[i] = ptr[i];

		delete [] ptr; 	// delete old vec
		ptr = vec2;							// make vec2 new vector
		for (int j = size - 1;  j>=r; j--) // add the element as normal
			ptr[j+1] = ptr[j]; 				// now that memory is allocated
		size++;
		ptr[r] = elem; 					
} 						
 	else {
		for (int j = size - 1;  j>=r; j--)	// insert element and shifting
			ptr[j+1] = ptr[j]; 
		size++;
		ptr[r] = elem; 						// copy contents of the vector
	}
		}
	
	

void My_vec:: replace_at_rank(int r, const char& elem){
	if (r < 0 || r > (size-1))
		cerr<<"RANK OUT OF RANGE";
	else 
		ptr[r] = elem;
}
// remove at rank is reference form page 233 code fragment
// 6.4
void My_vec::remove_at_rank(int r){ 
	if (r >= 0 && r <size){
		for (int j = r+1; j < size; j++)
			ptr[j]=ptr[j+1]; 				// shift elements
		size--;
	}
	else cerr << "RANK OUT OF RANGE";
	//ptr[r] = '0';
	//return size;
}
//////////////////////////////////////////////////////////
// out of class implementations:
// ostream based off of drill.8 from my 121 class
ostream& operator << (ostream& out, const My_vec& vec){
	for (int i = 0; i < vec.get_size(); i++)
		out << '[' << vec.elem_at_rank(i) << ']' << endl;
	return out;
}
// i referenced code fragment 4.1 from page 166 from textbook
int find_max_index(const My_vec& v, int size){
	int j = 0;
	int i = 1;
	int vecsize = v.get_size();
	if (size > vecsize) cerr << "RANK OUT OF RANGE";
	if (size == 1)return 0;
	else {
		while(i < size){
			if(v[j] < v[i])
				j = i;
		i++;
		}
	return j; // the current max index
	}
}
void sort_max(My_vec& vec){				// using find max index in sort_max
	if (vec.is_empty())
		cerr << "CANNOT SORT EMPTY VECTOR" << endl;
/*  	My_vec vec2 = vec; // holding vector
	int size = vec.get_size();
	for (int i = 0; i < (size-1); i++){
		int index = find_max_index(vec,size);
		vec[index] = vec2[i];
		vec.remove_at_rank(index);
	} */
 	My_vec vec2 = vec;
	int size = vec.get_size();
    int index;
    int i = 0;
    while(size>i){
        index = find_max_index(vec,vec.get_size());
		vec2.insert_at_rank(0, vec[index]);
        vec.remove_at_rank(i);
        --size;
    } 
    vec = vec2; 
}