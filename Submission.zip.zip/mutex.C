/* 
    File: mutex.H

    Author: Laura Austin
            Department of Computer Science
            Texas A&M University
    Date  : 07/14/16

*/
#include "mutex.H"
#include <pthread.h>

Mutex::Mutex(){
	pthread_mutex_init(m, NULL);
}

Mutex::~Mutex(){
	pthread_mutex_destroy(m);
}

void Mutex::Lock(){
	pthread_mutex_lock(m);
}

void Mutex::Unlock(){
	pthread_mutex_unlock(m);
}
int main(){ return 0; }