/* 
    File: Semaphore.C

    Author: Laura Austin
            Department of Computer Science
            Texas A&M University
    Date  : 07/14/16

*/
#include "semaphore.H"
#include "mutex.H"
#include <pthread.h>
Semaphore::Semaphore(int _val){
	value = _val;
	pthread_cond_init(c, NULL);
	pthread_mutex_init(m, NULL);
}

Semaphore::~Semaphore(){
	pthread_cond_destroy(c);
	pthread_mutex_destroy(m);
}

int Semaphore::P(){
	pthread_mutex_lock(m);
	value --;
	if (value < 0){
		pthread_cond_wait(c, m);
		pthread_mutex_unlock(m);
	}
	else pthread_mutex_unlock(m);
}

int Semaphore::V(){
	pthread_mutex_lock(m);
	value++;
	if (value <= 0){
		pthread_cond_signal(c);
	}
	pthread_mutex_unlock(m);
}
