/* 
    File: dataserver.C

    Author: Laura Austin
            Department of Computer Science
            Texas A&M University
    Date  : 2016/07/14

    Dataserver main program for MP2 in CSCE 313
*/

#include "mutex_guard.H"

MutexGuard::MutexGuard(Mutex m){
	_m = m;
	m.Lock();
}

MutexGuard::~MutexGuard(){
	_m.Unlock();
}